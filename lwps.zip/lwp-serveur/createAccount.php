
<?php
include_once("./password.php");
if (!empty($_POST["pse"]) && !empty($_POST["mdp"])) {
    $JSON = json_decode(file_get_contents($CODE.".json"));
    if (!empty($JSON->users->{$_POST["pse"]}->IsExist)) {
        if (hash_equals($JSON->users->{$_POST["pse"]}->MDP, hash("md5",$_POST["mdp"]))) {
        setcookie("USER", $_POST["pse"], time()+1000, "/", $_SERVER["SERVER_NAME"]);
        setcookie("PASSWORD", $_POST["mdp"], time()+1000, "/", $_SERVER["SERVER_NAME"]);
        header("Location: ../success.php");    
    } else {
        header("Location: ../error.php");
        }
    } else {
        $JSON->users->{htmlspecialchars($_POST["pse"])} = new stdClass;
        $JSON->users->{htmlspecialchars($_POST["pse"])}->IsExist = true;
        $JSON->users->{htmlspecialchars($_POST["pse"])}->MDP = hash("md5",$_POST["mdp"]);
        $JSON->users->{htmlspecialchars($_POST["pse"])}->posts = [];
        file_put_contents($CODE.".json", json_encode($JSON));
        header("Location: ../success.php");    

    }
}
?>
