
<?php
$CODE="1234"
?>
