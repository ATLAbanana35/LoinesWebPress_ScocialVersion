<?php
echo "L'opération est un succès! redirection : <a href='./index.php'>Passer</a>";
?>
<script>
setTimeout(() => {
    window.location = "./index.php";
}, 2000);
</script>
