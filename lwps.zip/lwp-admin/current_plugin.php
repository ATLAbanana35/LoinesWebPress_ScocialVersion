<!DOCTYPE html>
<html lang="en">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <style data-merge-styles="true"></style>

    <meta http-equiv="X-UA-Compatible" content="IE=Edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>HTML</title>

    <!-- HTML -->

    <!-- Custom Styles -->
    <link rel="stylesheet" href="./HTML_files/style.css">
    <style type="text/css" id="tts-styles">
    [data-tts-block-id].tts-active {
        background: rgba(206, 225, 255, 0.9) !important;
    }

    [data-tts-sentence-id].tts-active {
        background: rgba(0, 89, 191, 0.7) !important;
    }
    </style>
</head>

<body cz-shortcut-listen="true">
    <div data-v-7d889ae9="" class="odm_extension image_downloader_wrapper">
        <!---->
    </div>
    <style>
    iframe {
        width: 100%;
        height: 100%;
        position: absolute;
        top: 0;
        left: 0;
    }

    .close {
        position: absolute;
        top: 0;
        color: white;
        left: 0;
    }
    </style>
    <iframe srcdoc="" frameborder="0"></iframe>
    <div class="GUI_BOX_NewObject" style="top: 0px;">
        <h3 class="GUI_BUTTON NewObject_menu">
            Menu
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor"
                class="bi bi-menu-app-fill" viewBox="0 0 16 16">
                <path
                    d="M0 1.5A1.5 1.5 0 0 1 1.5 0h2A1.5 1.5 0 0 1 5 1.5v2A1.5 1.5 0 0 1 3.5 5h-2A1.5 1.5 0 0 1 0 3.5v-2zM0 8a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2V8zm1 3v2a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-2H1zm14-1V8a1 1 0 0 0-1-1H2a1 1 0 0 0-1 1v2h14zM2 8.5a.5.5 0 0 1 .5-.5h9a.5.5 0 0 1 0 1h-9a.5.5 0 0 1-.5-.5zm0 4a.5.5 0 0 1 .5-.5h6a.5.5 0 0 1 0 1h-6a.5.5 0 0 1-.5-.5z">
                </path>
            </svg>
        </h3>
        <h3 class="GUI_BUTTON NewObject_sep">
            Separator
            <hr width="50">
        </h3>
        <h3 class="GUI_BUTTON NewObject_newPost">
            New Posts
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-card-list"
                viewBox="0 0 16 16">
                <path
                    d="M14.5 3a.5.5 0 0 1 .5.5v9a.5.5 0 0 1-.5.5h-13a.5.5 0 0 1-.5-.5v-9a.5.5 0 0 1 .5-.5h13zm-13-1A1.5 1.5 0 0 0 0 3.5v9A1.5 1.5 0 0 0 1.5 14h13a1.5 1.5 0 0 0 1.5-1.5v-9A1.5 1.5 0 0 0 14.5 2h-13z">
                </path>
                <path
                    d="M5 8a.5.5 0 0 1 .5-.5h7a.5.5 0 0 1 0 1h-7A.5.5 0 0 1 5 8zm0-2.5a.5.5 0 0 1 .5-.5h7a.5.5 0 0 1 0 1h-7a.5.5 0 0 1-.5-.5zm0 5a.5.5 0 0 1 .5-.5h7a.5.5 0 0 1 0 1h-7a.5.5 0 0 1-.5-.5zm-1-5a.5.5 0 1 1-1 0 .5.5 0 0 1 1 0zM4 8a.5.5 0 1 1-1 0 .5.5 0 0 1 1 0zm0 2.5a.5.5 0 1 1-1 0 .5.5 0 0 1 1 0z">
                </path>
            </svg>
        </h3>
        <h3 class="GUI_BUTTON NewObject_AllPosts">
            All Posts
            🌍
        </h3>
        <h3 class="GUI_BUTTON NewObject_footer">
            Footer
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-window-dock"
                viewBox="0 0 16 16">
                <path
                    d="M3.5 11a.5.5 0 0 0-.5.5v1a.5.5 0 0 0 .5.5h1a.5.5 0 0 0 .5-.5v-1a.5.5 0 0 0-.5-.5h-1Zm3.5.5a.5.5 0 0 1 .5-.5h1a.5.5 0 0 1 .5.5v1a.5.5 0 0 1-.5.5h-1a.5.5 0 0 1-.5-.5v-1Zm4.5-.5a.5.5 0 0 0-.5.5v1a.5.5 0 0 0 .5.5h1a.5.5 0 0 0 .5-.5v-1a.5.5 0 0 0-.5-.5h-1Z">
                </path>
                <path
                    d="M14 1a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2V3a2 2 0 0 1 2-2h12ZM2 14h12a1 1 0 0 0 1-1V5H1v8a1 1 0 0 0 1 1ZM2 2a1 1 0 0 0-1 1v1h14V3a1 1 0 0 0-1-1H2Z">
                </path>
            </svg>
        </h3>
        <h3 class="GUI_BUTTON NewObject_image">
            Image
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-card-image"
                viewBox="0 0 16 16">
                <path d="M6.002 5.5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0z"></path>
                <path
                    d="M1.5 2A1.5 1.5 0 0 0 0 3.5v9A1.5 1.5 0 0 0 1.5 14h13a1.5 1.5 0 0 0 1.5-1.5v-9A1.5 1.5 0 0 0 14.5 2h-13zm13 1a.5.5 0 0 1 .5.5v6l-3.775-1.947a.5.5 0 0 0-.577.093l-3.71 3.71-2.66-1.772a.5.5 0 0 0-.63.062L1.002 12v.54A.505.505 0 0 1 1 12.5v-9a.5.5 0 0 1 .5-.5h13z">
                </path>
            </svg>
        </h3>
        <h3 class="GUI_BUTTON NewObject_link">
            Lien
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-link-45deg"
                viewBox="0 0 16 16">
                <path
                    d="M4.715 6.542 3.343 7.914a3 3 0 1 0 4.243 4.243l1.828-1.829A3 3 0 0 0 8.586 5.5L8 6.086a1.002 1.002 0 0 0-.154.199 2 2 0 0 1 .861 3.337L6.88 11.45a2 2 0 1 1-2.83-2.83l.793-.792a4.018 4.018 0 0 1-.128-1.287z">
                </path>
                <path
                    d="M6.586 4.672A3 3 0 0 0 7.414 9.5l.775-.776a2 2 0 0 1-.896-3.346L9.12 3.55a2 2 0 1 1 2.83 2.83l-.793.792c.112.42.155.855.128 1.287l1.372-1.372a3 3 0 1 0-4.243-4.243L6.586 4.672z">
                </path>
            </svg>
        </h3>
        <h3 class="GUI_BUTTON NewObject_FoprmConnect">
            Formulaire de Connexion
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor"
                class="bi bi-person-fill-add" viewBox="0 0 16 16">
                <path
                    d="M12.5 16a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7Zm.5-5v1h1a.5.5 0 0 1 0 1h-1v1a.5.5 0 0 1-1 0v-1h-1a.5.5 0 0 1 0-1h1v-1a.5.5 0 0 1 1 0Zm-2-6a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z">
                </path>
                <path
                    d="M2 13c0 1 1 1 1 1h5.256A4.493 4.493 0 0 1 8 12.5a4.49 4.49 0 0 1 1.544-3.393C9.077 9.038 8.564 9 8 9c-5 0-6 3-6 4Z">
                </path>
            </svg>
        </h3>
        <h3 class="GUI_BUTTON NewObject_addAdderForm">
            Formulaire d'ajout de posts
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-plus-circle"
                viewBox="0 0 16 16">
                <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z"></path>
                <path
                    d="M8 4a.5.5 0 0 1 .5.5v3h3a.5.5 0 0 1 0 1h-3v3a.5.5 0 0 1-1 0v-3h-3a.5.5 0 0 1 0-1h3v-3A.5.5 0 0 1 8 4z">
                </path>
            </svg>
        </h3>
        <hr>
        <h3 class="MODIFY_PLACE">
            Modifier la place des elements
        </h3>
        <div class="tre">
            <hr>

            <h3 class="ID_RickRoll_Gentil">
                <form action="http://localhost/loinesCloudOfficial/lwpsTEST/home/action.php?type=addYOurOwn"
                    method="post">
                    <input name="content" type="hidden"
                        value="&lt;iframe width=&quot;1261&quot; height=&quot;719&quot; src=&quot;https://www.youtube.com/embed/dQw4w9WgXcQ&quot; title=&quot;Rick Astley - Never Gonna Give You Up (Official Music Video)&quot; frameborder=&quot;0&quot; allow=&quot;accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share&quot; allowfullscreen&gt;&lt;/iframe&gt;"
                        class="ValueAMettreToID_RickRoll_Gentil">
                    <h3><input type="submit" value="RickRoll_Gentil"
                            style="background: none; color: white; border: none;"></h3>
                </form>
            </h3>

            <h3 class="ID_RickRoll_Agressif">
                <form action="http://localhost/loinesCloudOfficial/lwpsTEST/home/action.php?type=addYOurOwn"
                    method="post">
                    <input name="content" type="hidden"
                        value="&lt;iframe width=&quot;1261&quot; height=&quot;719&quot; src=&quot;https://rickroll.it/rickroll.mp4&quot; title=&quot;Rick Astley - Never Gonna Give You Up (Official Music Video)&quot; frameborder=&quot;0&quot; allow=&quot;accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share&quot; allowfullscreen&gt;&lt;/iframe&gt;"
                        class="ValueAMettreToID_RickRoll_Agressif">
                    <h3><input type="submit" value="RickRoll_Agressif"
                            style="background: none; color: white; border: none;"></h3>
                </form>
            </h3>
        </div>
    </div>
    <div class="close">close <div class="tuto_box">
            ⬆️ ICI : le moyen de fermer l'éditeur pour mieux voir la page. Cliquez dessus. Puis sur open
        </div>
    </div>
    <!-- Project -->
    <div style="display: none;" class="UUID_692ed7b9-3c1e-4db4-8fb6-2a77f7c1c490">[]</div>
    <script>
    let toggle = false;
    document.querySelector(".close").addEventListener("click", () => {
        document.querySelector(".GUI_BOX_NewObject").innerHTML += `
        <div class="tuto_box_1 tuto_box">
            ⬆️ ICI : le moyen d'ajouter des elements à la page : cliquez sur Menu
        </div>
        `;
        document.querySelector(".NewObject_menu").addEventListener("click", () => {
            document.querySelector(".tuto_box_1").style.display = "none";
            document.querySelectorAll(".tuto_box_1")[1].style.display = "none";
            document.body.innerHTML += `
            <div class="form" class="form">
    Menu :
    <br>

<label for="s768">Titre</label>
<input id="s768" type="text" name="Name">
<br>

<input class="valider" type="submit" name="submit" value="Valider">
<br>
</div>
            `
            document.querySelector(".form").innerHTML += `
        <div class="tuto_box">
            ⬆️ ICI : le moyen de personnaliser les elements de la page, mettez un titre et cliquez sur valider
        </div>
        `;
            document.querySelector(".valider").addEventListener("click", () => {
                document.querySelector(".tuto_box").remove();
                document.querySelector(".tuto_box").remove();
                document.querySelector(".tuto_box").remove();
                document.querySelector("iframe").srcdoc = `
            
        <link rel="stylesheet" href="../lwp-libs/css.css" />
        <menu>
          ${document.querySelector("#s768").value} :
          <ul class="MenuJson menu-bar"></ul>
        </menu>
        <button style="border-radius: 10%;" class="h6">Open Menu</button>
        <script type="module">
          import { xlm_menu } from "../lwp-libs/js.js";
          xlm_menu();
    \<\/script>

    `
                document.querySelector(".close").addEventListener("click", () => {
                    document.querySelector(".tuto_box").remove();
                    document.querySelector(".GUI_BOX_NewObject").innerHTML += `
                <div class="tuto_box">
            ⬆️ ICI : Encore Mieux!, maintenant voyons comment mettre en place en formulaire de connexion, (dernier tuto) cliquez sur Formulaire de Connexion 
        </div>
                `;
                    document.querySelector(".NewObject_FoprmConnect").addEventListener(
                        "click", () => {
                            document.body.innerHTML += `
            <div class="form" class="form">
    Formulaire de connexion :
    <br>

<label for="s545">Slogan (genre Bienvenue!)</label>
<input id="s545" type="text" name="Slogan">
<br>

<label for="s235">Futuriste (F), Ancien, (A), Basé sur une couleur : (C)</label>
<input id="s235" type="text" name="Style">
<br>

<label for="s752">(UNIQUEMENT SI C)</label>
<input id="s752" type="color" name="Color">
<br>

<input class="submit" type="submit" name="submit" value="Valider">
<br>
</div>
            `;
                            document.querySelector(".tuto_box").remove();

                            document.querySelector(".form").innerHTML += `
        <div class="tuto_box" style="z-index: 100000;    top: 200%;">
            ⬆️ ICI : le moyen de personnaliser les elements de la page, mettez un slogan, mettez F, et enfin cliquez sur valider
        </div>
        `;
                            document.querySelector(".submit").addEventListener(
                                "click", () => {
                                    document.querySelector("iframe").srcdoc += `

                                    <main>
        <form action="../lwp-serveur/createAccount.php" method="post">
          <h1>${document.querySelector("#s545").value}</h1>
          <div class="form-group">
            <label for="pseudo">Pseudo</label>
            <input id="pseudo" name="pse" type="text" placeholder="Entrez votre pseudo" required>
            <div class="underline"></div>
          </div>
          <div class="form-group">
            <label for="password">Mot de passe</label>
            <input id="password" name="mdp" type="password" placeholder="Entrez votre mot de passe" required>
            <div class="underline"></div>
          </div>
          <button type="submit" class="btn">Valider</button>
        </form>
      </main>
        <style>
    
        main {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 20vh;
            overflow: scroll;
            }
            
            form {
            display: flex;
            flex-direction: column;
            background: #f2f2f2;
            padding: 40px;
            border-radius: 10px;
            box-shadow: 0px 15px 30px rgba(0, 0, 0, 0.2);
            overflow: scroll;
            height: 90%;
            width: 90%;
            }
            
            h1 {
            font-size: 2rem;
            text-align: center;
            margin-bottom: 30px;
            }
            
            .form-group {
            position: relative;
            margin-bottom: 30px;
            }
            
            label {
            position: absolute;
            top: 0;
            left: 0;
            color: #999;
            font-size: 1rem;
            transform-origin: 0 0;
            transition: all 0.2s ease-out;
            }
            
            input {
            border: none;
            border-bottom: 2px solid #ddd;
            padding: 20px 0;
            font-size: 1.2rem;
            width: 100%;
            }
            
            .underline {
            position: absolute;
            bottom: 0;
            left: 0;
            width: 100%;
            height: 2px;
            background: #2196f3;
            transform: scaleX(0);
            transform-origin: 0 0;
            transition: all 0.2s ease-out;
            }
            
            input:focus + .underline,
            input:not(:placeholder-shown) + .underline {
            transform: scaleX(1);
            }
            
            .btn {
            background: #2196f3;
            color: #fff;
            border: none;
            border-radius: 5px;
            padding: 10px 20px;
            font-size: 1.2rem;
            cursor: pointer;
            transition: all 0.2s ease-out;
            }
            
            .btn:hover {
            background: #0d8ae5;
            }
        </style>
        
                                    `

                                    document.querySelector(".form").innerHTML += `
        <div class="tuto_box" style="z-index: 100000;    top: 200%;">
            INCROYABLE!, maintenant vous êtes près pour faire de VRAIES page, merci d'avoir installé LWPS <a href="../lwp-admin/">Créateur de pages ICI : </a>
        </div>
        `;
                                })
                        })
                    if (!toggle) {
                        document.querySelector(".GUI_BOX_NewObject").style.top =
                            "-1000px";
                        document.querySelector(".close").textContent = "open";
                        toggle = true;
                    } else {
                        document.querySelector(".GUI_BOX_NewObject").style.top = "0px";
                        document.querySelector(".close").textContent = "close";
                        toggle = false;
                    }
                });
                document.querySelector(".close").innerHTML += `
                <div class="tuto_box">
            ⬆️ ICI : Très bien! maintenant cliquez sur close pour voir le menu
        </div>
                `
            })
        })
        if (!toggle) {
            document.querySelector(".GUI_BOX_NewObject").style.top = "-1000px";
            document.querySelector(".close").textContent = "open";
            toggle = true;
        } else {
            document.querySelector(".GUI_BOX_NewObject").style.top = "0px";
            document.querySelector(".close").textContent = "close";
            toggle = false;
        }
    });
    </script>

    <style>
    body {
        font-size: 15pt;
        font-family: Arial;
    }

    .GUI_BOX_NewObject {
        position: absolute;
        left: 0;
        top: 0;
        color: white;
        background: rgba(0, 0, 0, 1);
        transition: 1s;
    }

    .GUI_BUTTON {
        border: 1px solid black;
        padding: 10px;
    }

    .close {
        z-index: 1000;
        position: absolute;
    }

    .form {
        position: absolute;
        z-index: 10000;
        background: rosybrown;
        padding: 20px;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
    }

    .tuto_box {
        position: absolute;
        width: 400px;
        height: 400px;
        border-radius: 5px;
        background: blue;
    }
    </style>
</body>

</html>