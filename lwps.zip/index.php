<?php
include_once("./lwp-serveur/password.php");
if (!empty($_COOKIE["LWPS_PASSWORD"])) {
    if ($_COOKIE["LWPS_PASSWORD"]==$CODE) {
        echo "Vous êtes ADMIN!<br><br> <a href='home'>Site (par default la page home)</a><br><br><a href='lwp-admin/'>Panel (pour créer des pages)</a>
        <br><br>Vous êtes nouveau?, Allez sur cette page :
         <a href='./lwp-admin/plugin.php'>ICI</a>
         puis rechercher \"Nom : Le meilleur plug-in de tutoriel (recommandé par le créateur de lwps)
         et cliquez sur \"Installer\", ensuite revenez ici et cliquez sur CE lien : <a href='./lwp-admin/panel.php'>CECI</a>,
         en dessous de la page : Le meilleur plug... en dessous il y as un lien cliquable, cliquez dessus,
         une fois le tutoriel fait, en voici un intégré : <a href='tuto.php'>Petit Tuto</a>
         \"";
} else {
    if (!is_dir("./home/")) {
        header("Location: ./lwp-admin");
    } else {
    header("Location: home/");
    }
}
} else {
    if (!is_dir("./home/")) {
        header("Location: ./lwp-admin");
    } else {
header("Location: home/");
}
    }
?>