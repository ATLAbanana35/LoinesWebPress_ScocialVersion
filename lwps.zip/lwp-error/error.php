
<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8" />
    <title>Erreur</title>
    <style>
    body {
        background-color: #1a1a1a;
        color: #fff;
        font-family: Arial, sans-serif;
    }

    h1 {
        font-size: 4em;
        text-align: center;
        margin-top: 100px;
    }

    p {
        font-size: 1.5em;
        text-align: center;
        margin-top: 30px;
    }

    a {
        color: #fff;
        text-decoration: underline;
    }
    </style>
</head>

<body>
    <h1>Erreur</h1>
    <p>
        Il semble que quelque chose ait mal tourné. Veuillez
        <a href="../index.php">retourner à l'accueil</a> et réessayer.
    <p>
        <br>
        "Compte non trouvé" : Ce message d'erreur peut être affiché si un utilisateur essaie de se connecter à un
        compte
        <br>
        qui n'existe pas dans la base de données. La suggestion de correction pourrait être de demander à
        l'utilisateur
        <br>
        de vérifier s'il a entré le nom d'utilisateur ou le mot de passe correctement, et de lui offrir la possibilité
        <br>
        de créer un nouveau compte s'il n'en a pas encore.
        <br>

        <br>
        "Formulaire non rempli" : Ce message d'erreur peut être affiché si un utilisateur essaie de soumettre un
        <br>
        formulaire sans avoir rempli tous les champs obligatoires. La suggestion de correction pourrait être d'indiquer
        <br>
        clairement quels champs sont obligatoires et d'afficher un message d'erreur spécifique pour chaque champ
        <br>
        manquant.
        <br>

        <br>
        "Page introuvable" : Ce message d'erreur peut être affiché si un utilisateur essaie d'accéder à une page qui
        <br>
        n'existe pas ou qui a été déplacée. La suggestion de correction pourrait être de rediriger l'utilisateur vers
        <br>
        une page similaire ou de lui offrir une recherche pour trouver la page qu'il cherche.
        <br>

        <br>
        "Erreur de chargement de page" : Ce message d'erreur peut être affiché si une page ne peut pas être chargée en
        <br>
        raison d'un problème technique. La suggestion de correction pourrait être de demander à l'utilisateur de
        <br>
        vérifier sa connexion Internet ou de contacter l'assistance technique pour obtenir de l'aide.
        <br>
    </p>
    </p>
</body>

</html>
