
<?php
include_once("../lwp-serveur/password.php");
if (!empty($_COOKIE["LWPS_PASSWORD"])) {
    if ($_COOKIE["LWPS_PASSWORD"] == $CODE) {


if (!empty($_POST)) {
    $file_name = (int) file_get_contents("content/number.txt");
    $file_name += 1;
    if ($_GET["type"] == "addMenu") {
        $Menu_Title = $_POST["Name"];
        file_put_contents("content/" . $file_name . ".txt", '
        <link rel="stylesheet" href="../lwp-libs/css.css" />
        <menu>
          '.$Menu_Title.' :
          <ul class="MenuJson menu-bar"></ul>
        </menu>
        <button style="border-radius: 10%;" class="h6">Open Menu</button>
        <script type="module">
          import { xlm_menu } from "../lwp-libs/js.js";
          xlm_menu();
        </script>
        ');
    }
    if ($_GET["type"] == "addSep") {
        $Menu_Color = $_POST["Color"];
        $Menu_Hauteur = $_POST["Width"];
        file_put_contents("content/" . $file_name . ".txt", '
        <hr style="height: '.$Menu_Hauteur.'px;background: '.$Menu_Color.';"></hr>
        ');
    }
    if ($_GET["type"] == "addForm_Connect") {
        $Form_Color = $_POST["Color"];
        $Form_Style = $_POST["Style"];
        $Menu_Color = $_POST["Slogan"];
        if ($Form_Style == "C") {

        $Menu_Color = $_POST["Slogan"];
        file_put_contents("content/" . $file_name . ".txt", '
        <main>
        <form action="../lwp-serveur/createAccount.php" method="post">
        <h1>'.$Menu_Color.'</h1>
        <br>
        <label for="pseudo">Pseudo</label>
        <br>
        <input id="pseudo" name="pse" type="text"></input>
        <br>
        <label for="password">Mot de passe</label>
        <br>
        <input id="password" name="mdp" type="password"></input>
        <br>
        <input type="submit" value="Valider"></input>
        </form>
        </main>
        <style>
    
        main {
            width: 100%;
            height: 70%;
            background-color: white;
            border: 10px solid black;
            border-radius: 20px;
            box-shadow: inset 0 0 20px 0px;
            overflow: scroll;
            background:  '.$Form_Color.';
        }
    
        input {
            padding: 10px;
            background: '.$Form_Color.';
            color: black;
            border-radius: 20px;
            transition: 0.5s;
        }
    
        input[type="submit"]:hover {
            letter-spacing: 5px;
        }
    
        .red {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            color: red;
        }
        </style>
        ');
    } elseif ($Form_Style == "F") {
        file_put_contents("content/" . $file_name . ".txt", '
        <main>
        <form action="../lwp-serveur/createAccount.php" method="post">
          <h1>'.$Menu_Color.'</h1>
          <div class="form-group">
            <label for="pseudo">Pseudo</label>
            <input id="pseudo" name="pse" type="text" placeholder="Entrez votre pseudo" required>
            <div class="underline"></div>
          </div>
          <div class="form-group">
            <label for="password">Mot de passe</label>
            <input id="password" name="mdp" type="password" placeholder="Entrez votre mot de passe" required>
            <div class="underline"></div>
          </div>
          <button type="submit" class="btn">Valider</button>
        </form>
      </main>
        <style>
    
        main {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 20vh;
            overflow: scroll;
            }
            
            form {
            display: flex;
            flex-direction: column;
            background: #f2f2f2;
            padding: 40px;
            border-radius: 10px;
            box-shadow: 0px 15px 30px rgba(0, 0, 0, 0.2);
            overflow: scroll;
            height: 90%;
            width: 90%;
            }
            
            h1 {
            font-size: 2rem;
            text-align: center;
            margin-bottom: 30px;
            }
            
            .form-group {
            position: relative;
            margin-bottom: 30px;
            }
            
            label {
            position: absolute;
            top: 0;
            left: 0;
            color: #999;
            font-size: 1rem;
            transform-origin: 0 0;
            transition: all 0.2s ease-out;
            }
            
            input {
            border: none;
            border-bottom: 2px solid #ddd;
            padding: 20px 0;
            font-size: 1.2rem;
            width: 100%;
            }
            
            .underline {
            position: absolute;
            bottom: 0;
            left: 0;
            width: 100%;
            height: 2px;
            background: #2196f3;
            transform: scaleX(0);
            transform-origin: 0 0;
            transition: all 0.2s ease-out;
            }
            
            input:focus + .underline,
            input:not(:placeholder-shown) + .underline {
            transform: scaleX(1);
            }
            
            .btn {
            background: #2196f3;
            color: #fff;
            border: none;
            border-radius: 5px;
            padding: 10px 20px;
            font-size: 1.2rem;
            cursor: pointer;
            transition: all 0.2s ease-out;
            }
            
            .btn:hover {
            background: #0d8ae5;
            }
        </style>
        ');
    } elseif ($Form_Style == "A") {
        file_put_contents("content/" . $file_name . ".txt", '
        <main>
  <form action="../lwp-serveur/createAccount.php" method="post">
    <h1>'.$Menu_Color.'</h1>
    <div class="form-group">
      <label for="pseudo">Nom d utilisateur</label>
      <input id="pseudo" name="pse" type="text">
    </div>
    <div class="form-group">
      <label for="password">Mot de passe</label>
      <input id="password" name="mdp" type="password">
    </div>
    <div class="form-group">
      <input type="submit" value="S enregistrer">
    </div>
  </form>
</main>

<style>
  /* Style du formulaire */
  main {
    background-color: #f5f5f5;
    border: 1px solid #ccc;
    box-shadow: 0px 0px 10px #ccc;
    margin: 50px auto;
    max-width: 600px;
    padding: 20px;
  }

  h1 {
    border-bottom: 2px solid #ccc;
    font-family: serif;
    font-size: 2em;
    margin-bottom: 20px;
    text-align: center;
    text-transform: uppercase;
  }

  .form-group {
    margin-bottom: 20px;
  }

  label {
    display: block;
    font-family: serif;
    font-size: 1.2em;
    font-weight: bold;
    margin-bottom: 10px;
  }

  input[type="text"],
  input[type="password"] {
    border: none;
    border-bottom: 1px solid #ccc;
    font-family: serif;
    font-size: 1.2em;
    padding: 10px;
    width: 100%;
  }

  input[type="submit"] {
    background-color: #8b0000;
    border: none;
    color: #fff;
    cursor: pointer;
    font-family: serif;
    font-size: 1.2em;
    padding: 10px 20px;
    text-transform: uppercase;
    transition: background-color 0.3s;
  }

  input[type="submit"]:hover {
    background-color: #b22222;
  }
</style>
        ');
    }
}
    if ($_GET["type"] == "addPostAdder") {
        $Form_Color = $_POST["Color"];
        $Form_Style = $_POST["Style"];
        $Menu_Color = $_POST["Slogan"];
        $Form_Police_Color = $_POST["ColorP"];
        if ($Form_Style == "C") {

        $Menu_Color = $_POST["Slogan"];
        file_put_contents("content/" . $file_name . ".txt", '
        
        <h1>'.$Menu_Color.'</h1>
        <br>
        <br>
        <button class="Img">Ajouter une image</button>
        <br>
        <br>
        <button class="Title">Ajouter un titre</button>
        <br>
        <br>
        <button class="Text">Ajouter du texte</button>
        <br>
        <br>
        <button class="Return">Retours</button>
        <br>
        <br>
        <form action="../lwp-serveur/CreatePost.php" method="post">
          <label for="Name">Nom de votre post</label>
          <input type="text" name="Name" id="Name" />
    
          <view></view>
          <input value="Contenu : " class="content" type="hidden" name="Content"></input>
          <input type="submit" value="Valider" id="" />
        </form>
        <style>
          .view {
            padding: 20px;
          }
        </style>
        <script>
          let Sauv = [""];
          let Current_Sauv = 0
          document.querySelector(".Img").addEventListener("click", () => {
            Current_Sauv++;
            let img = prompt("Image URL");
            document.querySelector(".content").value += `
            <img src="${img}"></img>
            `;
            document.querySelector("view").innerHTML = document.querySelector(".content").value;
            console.log(document.querySelector(".content").value);
            Sauv.push(document.querySelector(".content").value);
          });
          document.querySelector(".Title").addEventListener("click", () => {
            Current_Sauv++;
            let img = prompt("Texte");
            document.querySelector(".content").value += `
            <h3>${img}</h3>
            `;
            document.querySelector("view").innerHTML = document.querySelector(".content").value;
            console.log(document.querySelector(".content").value);
            Sauv.push(document.querySelector(".content").value);
          });
          document.querySelector(".Text").addEventListener("click", () => {
            Current_Sauv++;
            let img = prompt("Texte");
            document.querySelector(".content").value += `
            <p>${img}</p>
            `;
            document.querySelector("view").innerHTML = document.querySelector(".content").value;
            console.log(document.querySelector(".content").value);
            Sauv.push(document.querySelector(".content").value);
          })
          document.querySelector(".Return").addEventListener("click", () => {
            Current_Sauv--;
          })
          setInterval(() => {
            document.querySelector(".content").value = Sauv[Current_Sauv];
            document.querySelector("view").innerHTML = document.querySelector(".content").value;
          }, 100);
        </script>
        <style>
          /* Normal */
          button {
      background-color: '.$Form_Color.';
      color: '.$Form_Police_Color.';
      font-size: 1rem;
      padding: 0.5rem 1rem;
      border: none;
      border-radius: 4px;
      cursor: pointer;
      margin-right: 1rem;
    }
    
    button:hover {
      background-color: '.$Form_Color.';
    }
    
    label {
      display: block;
      margin-top: 1rem;
    }
    
    input[type="text"] {
      padding: 0.5rem;
      border-radius: 4px;
      border: 1px solid #ccc;
      width: 100%;
      box-sizing: border-box;
      margin-bottom: 1rem;
    }
    
    input[type="submit"] {
      background-color: '.$Form_Color.';
      color: #fff;
      font-size: 1rem;
      padding: 0.5rem 1rem;
      border: none;
      border-radius: 4px;
      cursor: pointer;
    }
    
    input[type="submit"]:hover {
      background-color: '.$Form_Color.';
    }
        ');
    } elseif ($Form_Style == "F") {
        file_put_contents("content/" . $file_name . ".txt", '
        <button class="Img">Ajouter une image</button>
        <br>
        <br>
        <button class="Title">Ajouter un titre</button>
        <br>
        <br>
        <button class="Text">Ajouter du texte</button>
        <br>
        <br>
        <button class="Return">Retours</button>
        <br>
        <br>
        <form action="../lwp-serveur/CreatePost.php" method="post">
          <label for="Name">Nom de votre post</label>
          <input style="color: white;" type="text" name="Name" id="Name" />
    
          <view></view>
          <input value="Contenu : " class="content" type="hidden" name="Content"></input>
          <input type="submit" value="Valider" id="" />
        </form>
        <style>
          .view {
            padding: 20px;
          }
        </style>
        <script>
          let Sauv = [""];
          let Current_Sauv = 0
          document.querySelector(".Img").addEventListener("click", () => {
            Current_Sauv++;
            let img = prompt("Image URL");
            document.querySelector(".content").value += `
            <img src="${img}"></img>
            `;
            document.querySelector("view").innerHTML = document.querySelector(".content").value;
            console.log(document.querySelector(".content").value);
            Sauv.push(document.querySelector(".content").value);
          });
          document.querySelector(".Title").addEventListener("click", () => {
            Current_Sauv++;
            let img = prompt("Texte");
            document.querySelector(".content").value += `
            <h3>${img}</h3>
            `;
            document.querySelector("view").innerHTML = document.querySelector(".content").value;
            console.log(document.querySelector(".content").value);
            Sauv.push(document.querySelector(".content").value);
          });
          document.querySelector(".Text").addEventListener("click", () => {
            Current_Sauv++;
            let img = prompt("Texte");
            document.querySelector(".content").value += `
            <p>${img}</p>
            `;
            document.querySelector("view").innerHTML = document.querySelector(".content").value;
            console.log(document.querySelector(".content").value);
            Sauv.push(document.querySelector(".content").value);
          })
          document.querySelector(".Return").addEventListener("click", () => {
            Current_Sauv--;
          })
          setInterval(() => {
            document.querySelector(".content").value = Sauv[Current_Sauv];
            document.querySelector("view").innerHTML = document.querySelector(".content").value;
          }, 100);
        </script>
        <style>
        main {
          background-color: #000;
          border: none;
          box-shadow: 0px 0px 20px #00ffff, 0px 0px 40px #00ffff, 0px 0px 60px #00ffff, 0px 0px 80px #00ffff;
          margin: 50px auto;
          max-width: 600px;
          padding: 20px;
        }
        
        h1 {
          color: #00ffff;
          font-family: "Orbitron", sans-serif;
          font-size: 3em;
          margin-bottom: 30px;
          text-align: center;
          text-transform: uppercase;
          text-shadow: 0px 0px 10px #00ffff;
        }
        
        .form-group {
          margin-bottom: 30px;
        }
        
        label {
          color: #00ffff;
          display: block;
          font-family: "Orbitron", sans-serif;
          font-size: 1.5em;
          font-weight: bold;
          margin-bottom: 10px;
          text-shadow: 0px 0px 10px #00ffff;
        }
        
        input[type="text"],
        input[type="password"] {
          background-color: transparent;
          border: none;
          border-bottom: 2px solid #00ffff;
          color: #fff;
          font-family: "Orbitron", sans-serif;
          font-size: 1.2em;
          padding: 10px;
          width: 100%;
        }
        
        input[type="submit"],button {
          background-color: #00ffff;
          border: none;
          color: #000;
          cursor: pointer;
          font-family: "Orbitron", sans-serif;
          font-size: 1.5em;
          padding: 10px 20px;
          text-transform: uppercase;
          transition: background-color 0.3s;
        }
        
        input[type="submit"]:hover {
          background-color: #fff;
          color: #000;
        }
        </style>
        ');
    } elseif ($Form_Style == "A") {
        file_put_contents("content/" . $file_name . ".txt", '
        <button class="Img">Ajouter une image</button>
        <br>
        <br>
        <button class="Title">Ajouter un titre</button>
        <br>
        <br>
        <button class="Text">Ajouter du texte</button>
        <br>
        <br>
        <button class="Return">Retours</button>
        <br>
        <br>
        <form action="../../lwp-serveur/CreatePost.php" method="post">
          <label for="Name">Nom de votre post</label>
          <input type="text" name="Name" id="Name" />
    
          <view></view>
          <input value="Contenu : " class="content" type="hidden" name="Content"></input>
          <input type="submit" value="Valider" id="" />
        </form>
        <style>
          .view {
            padding: 20px;
          }
        </style>
        <script>
          let Sauv = [""];
          let Current_Sauv = 0
          document.querySelector(".Img").addEventListener("click", () => {
            Current_Sauv++;
            let img = prompt("Image URL");
            document.querySelector(".content").value += `
            <img src="${img}"></img>
            `;
            document.querySelector("view").innerHTML = document.querySelector(".content").value;
            console.log(document.querySelector(".content").value);
            Sauv.push(document.querySelector(".content").value);
          });
          document.querySelector(".Title").addEventListener("click", () => {
            Current_Sauv++;
            let img = prompt("Texte");
            document.querySelector(".content").value += `
            <h3>${img}</h3>
            `;
            document.querySelector("view").innerHTML = document.querySelector(".content").value;
            console.log(document.querySelector(".content").value);
            Sauv.push(document.querySelector(".content").value);
          });
          document.querySelector(".Text").addEventListener("click", () => {
            Current_Sauv++;
            let img = prompt("Texte");
            document.querySelector(".content").value += `
            <p>${img}</p>
            `;
            document.querySelector("view").innerHTML = document.querySelector(".content").value;
            console.log(document.querySelector(".content").value);
            Sauv.push(document.querySelector(".content").value);
          })
          document.querySelector(".Return").addEventListener("click", () => {
            Current_Sauv--;
          })
          setInterval(() => {
            document.querySelector(".content").value = Sauv[Current_Sauv];
            document.querySelector("view").innerHTML = document.querySelector(".content").value;
          }, 100);
        </script>
        <style>
        main {
          background-color: #f5f5f5;
          border: 1px solid #ccc;
          box-shadow: 0px 0px 10px #ccc;
          margin: 50px auto;
          max-width: 600px;
          padding: 20px;
        }
        
        h1 {
          border-bottom: 2px solid #ccc;
          font-family: Georgia, "Times New Roman", serif;
          font-size: 2em;
          margin-bottom: 20px;
          text-align: center;
          text-transform: uppercase;
        }
        
        .form-group {
          margin-bottom: 20px;
        }
        
        label {
          display: block;
          font-family: Georgia, "Times New Roman", serif;
          font-size: 1.2em;
          font-weight: bold;
          margin-bottom: 10px;
        }
        
        input[type="text"],
        input[type="password"] {
          border: none;
          border-bottom: 1px solid #ccc;
          font-family: Georgia, "Times New Roman", serif;
          font-size: 1.2em;
          padding: 10px;
          width: 100%;
        }
        
        input[type="submit"],button {
          background-color: #8b0000;
          border: none;
          color: #fff;
          cursor: pointer;
          font-family: Georgia, "Times New Roman", serif;
          font-size: 1.2em;
          padding: 10px 20px;
          text-transform: uppercase;
          transition: background-color 0.3s;
        }
        
        input[type="submit"]:hover {
          background-color: #b22222;
        }
</style>
        ');
    }
}
    if ($_GET["type"] == "addAct_NewPosts") {
        $Menu_Color = $_POST["Slogan"];
        file_put_contents("content/" . $file_name . ".txt", '
        <div style="height:50vh;">
        <iframe style="width:100%; height:100%;" src="./newPosts.php?number='.$_POST["NumberOfPosts"].'"></iframe>
</div>

        ');
    }
    if ($_GET["type"] == "addYOurOwn") {
      file_put_contents("content/" . $file_name . ".txt", $_POST["content"]);
    }
    if ($_GET["type"] == "addImg") {
        $Img_Source = $_POST["Source"];
        $Img_Width = $_POST["Width"];
        file_put_contents("content/" . $file_name . ".txt", '
        <style>
        .img {
            width: '.$Img_Width.'%;
            display: block;
            margin-left: auto;
            margin-right: auto;
        }
        </style>
        <img src="'.$Img_Source.'" class="img"></img>
        ');
    }
    if ($_GET["type"] == "addLink") {
        $Lien_URL = $_POST["Lien"];
        $Lien_Texte = $_POST["Texte"];
        file_put_contents("content/" . $file_name . ".txt", '
        <a href="'.$Lien_URL.'" style="text-decoration: none;text-align: center;display: block; color: black;">'.$Lien_Texte.'</a>
        ');
    }
    if ($_GET["type"] == "allPosts") {
        file_put_contents("content/" . $file_name . ".txt", '
        <div style="height:50vh;">

        <iframe style="width:100%; height:100%;" src="./allPost.php"></iframe>
        </div>


        ');
    }
    if ($_GET["type"] == "addFooter") {
        $Footer_Color = $_POST["Color"];
        $Text_Color = $_POST["ColorP"];
        $Footer_Name = $_POST["Name"];
        $Dev = $_POST["Dev"];
        file_put_contents("content/" . $file_name . ".txt", '
        <style>
        footer {
            background-color: '.$Footer_Color.';
            color: '.$Text_Color.';
            padding: 20px 0;
            font-family: sans-serif;
            font-size: 14px;
          }
          
          .footer-container {
            display: flex;
            flex-wrap: wrap;
            justify-content: space-between;
            align-items: center;
            max-width: 1200px;
            margin: 0 auto;
          }
          
          .logo {
            display: flex;
            align-items: center;
          }
          
          .logo img {
            width: 50px;
            margin-right: 10px;
          }
          
          .powered-by,
          .site-name {
            text-align: center;
          }
          
          .powered-by h3,
          .site-name h3 {
            margin: 0;
            font-weight: 400;
            text-transform: uppercase;
          }
          
          .powered-by h3 {
            font-size: 12px;
          }
          
          .site-name h3 {
            font-size: 18px;
          }
          
        </style>
        <footer>
        <div class="footer-container">
          <div class="logo">
            <img src="https://loines.ch/assetshome/image/loineslogo.png" alt="Logo">
            <h3>'.$Dev.'</h3>
          </div>
          <div class="powered-by">
            <h3>Powered By Loines Cloud</h3>
          </div>
          <div class="site-name">
            <h3>'.$Footer_Name.'</h3>
          </div>
        </div>
      </footer>
      
        ');
    }
    file_put_contents("content/number.txt", $file_name);
    include_once "content/list.php";
    $NewList = $list;
    array_push($NewList, $file_name);
    print_r($NewList);
    $StringNewList = json_encode($NewList);
  
    file_put_contents("content/list.php", "
    <?php
    \$list = $StringNewList;
    ?>
");
header("Location: ./modify.php");
}
} else {
header("Location: ../lwp-error/start.php");
}
} else {
header("Location: ../lwp-error/start.php");
}
?>
