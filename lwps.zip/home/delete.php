
<?php
include_once("../lwp-serveur/password.php");
if (!empty($_COOKIE["LWPS_PASSWORD"])) {
    if ($_COOKIE["LWPS_PASSWORD"] == $CODE) {
include_once "content/list.php";
$NewList = $list;
unset($NewList[$_GET["file"]]);
print_r($NewList);
$NewNewList = [];
foreach ($NewList as $key => $value) {
  array_push($NewNewList, $value);
}
$StringNewList = json_encode($NewNewList);

file_put_contents("content/list.php", "
<?php
\$list = $StringNewList;
?>
");
header("Location: ./modifyIner.php");

} else {
header("Location: ../lwp-error/start.php");
}
} else {
header("Location: ../lwp-error/start.php");
}
?>