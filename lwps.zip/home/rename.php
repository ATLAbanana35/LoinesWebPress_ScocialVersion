
<?php
include_once("../lwp-serveur/password.php");
if (!empty($_COOKIE["LWPS_PASSWORD"])) {
    if ($_COOKIE["LWPS_PASSWORD"] == $CODE) {
            file_put_contents("content/list.php", "
<?php
\$list = ".$_POST["elements"].";
?>
");
echo 'File moved successfully';
header("Location: modify.php");
} else {
header("Location: ../lwp-error/start.php");
}
} else {
header("Location: ../lwp-error/start.php");
}
?>
