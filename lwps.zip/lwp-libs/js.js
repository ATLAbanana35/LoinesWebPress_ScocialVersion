
export function xlm_menu() {
let xlm2 = new XMLHttpRequest();
xlm2.responseType = "json";
xlm2.open("GET", "../lwp-client/pages.json");
xlm2.send();
xlm2.onload = function () {
let object = xlm2.response;
for (const key in object) {
if (Object.hasOwnProperty.call(object, key)) {
const element = object[key];
document.querySelector(".MenuJson").innerHTML += `
<li class="Menu-Item"><a href='../${element.path}'>${element.name}</a></li>
`;
}
}
};
document.addEventListener("scroll", (e) => {
if (window.scrollY > 100) {
document.querySelector("menu").style.top = "-1000px";
} else {
document.querySelector("menu").style.top = "0px";
document.querySelector("menu").style.top = window.scrollY + "px";
}
});
document.querySelector(".h6").addEventListener("click", () => {
document.querySelector("menu").style.top = "0px";
});
setTimeout(() => {
document.querySelector("menu").style.top = "-1000px";
}, 2000);
}

