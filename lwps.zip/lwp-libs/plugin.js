const XML = new XMLHttpRequest();
XML.open("GET", "../lwp-client/plugins.json");
XML.responseType = "json";
document.querySelector(".tre").innerHTML += `
<hr>
`;
XML.onload = function () {
  let result = XML.response;
  for (const PlugIn in result) {
    if (Object.hasOwnProperty.call(result, PlugIn)) {
      for (const Addons in result[PlugIn]["NewActions"]) {
        if (Object.hasOwnProperty.call(result[PlugIn]["NewActions"], Addons)) {
          let element = result[PlugIn]["NewActions"][Addons];
          document.querySelector(".tre").innerHTML += `
              <h3 class="ID_${Addons}">
                    <form action="action.php?type=addYOurOwn" method="post">
                    <input name="content" type="hidden" value="" class="ValueAMettreToID_${Addons}"></input>
                    <h3><input type="submit" value="${Addons}" style="background: none; color: white; border: none;"></input></h3>
                    </form>
                </h3>
                <hr style="background: gray;">
              `;
          for (const Data in result[PlugIn]["NewActionsData"][Addons]) {
            if (
              Object.hasOwnProperty.call(
                result[PlugIn]["NewActionsData"][Addons],
                Data
              )
            ) {
              const DataElement =
                result[PlugIn]["NewActionsData"][Addons][Data];
              document.querySelector(".ID_" + Addons).innerHTML += `
              <button class="ID_${Addons}_VALUE_${Data}">Ajuster la valeur : ${Data}</button>
              `;
              setTimeout(() => {
                document
                  .querySelector(`.ID_${Addons}_VALUE_${Data}`)
                  .addEventListener("click", () => {
                    const response = prompt(DataElement);
                    console.log(element.indexOf(":" + Data));
                    element = element.replace(":" + Data, response);
                    document.querySelector(
                      ".ValueAMettreToID_" + Addons
                    ).value = element;
                  });
              }, 100);
            }
          }
          document.querySelector(".ValueAMettreToID_" + Addons).value = element;
        }
      }
    }
  }
};
XML.send();
